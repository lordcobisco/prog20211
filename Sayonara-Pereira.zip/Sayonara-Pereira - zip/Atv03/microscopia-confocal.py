print("Esta é uma interface de configuração de microscópico confocal para análise de imagem! \n")

profundidadeCampo = int(input("Digite 0 para alta profundidade de campo ou 1 para baixa profundidade de campo \n" ))

print("Houve alteração na variável inserida? "); print(bool)

contraste = int(input("Digite 0 para aumento de contraste ou 1 para diminuição de contraste \n"))

print("Houve alteração na variável inserida? "); print(bool)

foco = int(input("Digite 0 para aumetar o foco ou 1 para diminuir o foco \n"))

print("Houve alteração na variável inserida? "); print(bool)

zoom1 = 1
zoom2 = 2
zoom3 = 10
zoom4 = 20

print("Em quantas vezes você deseja o zoom? (1x, 2x, 10x ou 20x \n")
print("Houve alteração na variável inserida?")

resolucao = int(input("Insira o dígito 0 para aumentar a resolução ou 1 para diminuir a resolução \n"))
print("Houve alteração na variável inserida?"); print(bool)

celula = int(input('Digite 0 para células humanas ou 1 para células animais \n')
print("Houve alteração na variável inserida?"); print(bool)

corFluorescente = int(input("Digite 0 para cor verde ou 1 para cor vermelha \n"))
print("Houve alteração na variável inserida?"); print(bool)

iluminacao = int(input("Digite 0 para aumetar a iluminação ou 1 para diminuir a iluminação \n"))
print("Houve alteração na variável inserida?"); print(bool)

lamina = int(input("Digite 0 para uma lâmina mais fina ou 1 para lâmina de maior espessura \n"))
print("Houve alteração na variável inserida?"); print(bool)

saturacao = int(input("Digite 0 para aumentar a saturação ou 1 para diminuir a saturação \n"))
print("Houve alteração na variável inserida?"); print(bool)

print("As informações de configuração são: \n Profundidade: " , profundidadeCampo)
print("\n Contraste: " , contraste)
print("\n Foco: " , foco)
print("\n Zoom: " , zoom1)
print("\n Resolução: " , resolucao)
print(" Célula \n: " , celula)
print(" Cor: \n" , corFluorescente)
print(" Iluminação: \n" , iluminacao)
print(" Lâmina: \n" , lamina)
print(" Saturação: \n" , saturacao)

print("Configurações iniciais realizadas! Agora calibre horizontalmente o dispositivo \n")

calibreHorizontal = input("Digite 10 vezes a primeira letra do seu nome e 10 vezes a ultima letra do seu nome \n")
print("Dispositivo horizontalmente calibrado! " ,  calibreHorizontal)

calibreVertical = input("Digite 2x a segunda letra do seu nome e 2x a penúltima letra do seu nome para calibre vertical \n")
print("Dispositivo verticalmente calibrado! \n " ,  calibreVertical)

print("Microscópio configurado e pronto para uso, bons estudos!")