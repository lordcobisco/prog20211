##### NUMPY #####
'''pacote fundamental para computação científica'''

# numpy
# scipy
# matplotlib
# ipython
# jupter
# pandas
# sympy
# nose
# scikit-learn
# scikit-image
# control
# bokeh

import numpy as np
