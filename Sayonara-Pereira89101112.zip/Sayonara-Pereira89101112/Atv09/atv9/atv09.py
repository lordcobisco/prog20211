# problema na linha 34
# não tenho certeza se consegui abstrair o suficiente para cumprir com toda a questão (acho que não)

import csv
import numpy as np

flexJoelho = open('Sayonara-Pereira\Atv08\coletaFlexJoelho.csv', 'r')

dados = []

for row in flexJoelho:
    dadosRaw = row.split('],""[')
    dadosRaw1 = dadosRaw[0].split('[')[1]
    dadosRaw2 = dadosRaw[1].split(']"""')[0]

    for dadosClean1 in dadosRaw1.split(","):
        dados.append(float(dadosClean1))
    for dadosClean2 in dadosRaw2.split(","):
        dados.append(float(dadosClean2))

print(dados)

def variaveisDeCalculo (dados):
  return np.arctan(dados[0]/(np.sqrt(dados[1]**2 + dados[2]**2))) * 180/np.pi

dadosFlexJoelhoTxt = open('FlexJoelho.txt', 'w')
print(dadosFlexJoelhoTxt)
dadosFlexJoelhoTxt.write("Estes são os dados FlexJoelho: ")
dadosFlexJoelhoTxt.write('dados')
dadosFlexJoelhoTxt.write('variaveisDeCalculo')
dadosFlexJoelhoTxt.close()

import csv
with open('DadosFlexJoelho.csv', 'w', newline='\n') as CalculoFlexJoelho:
  wr = csv.writer(variaveisDeCalculo, delimiter=',') # botei o spamwirter e o wr, mas continua pedindo uma "função" de escrita

dicionario = {}
dicionario['DadosFlexJoelho'] = {'Dados':[dados], 'Fórmula1':['ax/np.(sqrt(ay**2+az**2))*180/3.14'], 'Fórmula2':['0.98*(veloAngularX+dadow*0.05)+(1-0.98)*Fórmula1']}
print(dicionario)