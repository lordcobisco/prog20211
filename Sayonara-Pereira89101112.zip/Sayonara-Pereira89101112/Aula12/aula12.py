# import pandas as pd
# dtype=float64


# datas = pd.date_range('20130101', periods=6)
# df = pd.DataFrame(mp.random.radn(6,4), index=datas, columns=list('ABCD'))
# print(df)

# df2 = pd.DataFrame({'A':1.,
#                     'B':pd.Timestamp('20130102'),
#                     'C':pd.Series(1,index=list(range(4))),
#                     dtype='float32', 
#                     'D':np.array([3]*4,dtype=='int32'),
#                     'E'pd.Categorical(['test','train','test', 'train']),
#                     'F':'string'})
# print(df2)
# print(df2.dtypes)
# df.headdf.columns
# df.to_numpy()
# df2.describe()
# df.T
# df.sort_index(axis=1,ascending=False)
# df.sort_values(by='B')
# df.append
# df[0:3]
# df.loc[datas[0]]
# df.loc[:,['A',['B']]]

# df.iat[1,1]
