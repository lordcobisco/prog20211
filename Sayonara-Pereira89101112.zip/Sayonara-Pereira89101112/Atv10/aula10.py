# indexando com vetor de índices

#import numpy as np
# a = np.arange(12)*2; print(a)
# i = np.array([1,3,8,5])
# print(a[i])
# j = np.array([[3,4],[9,7]])
# print(a[j])

# palette = np.array([[0,0,0],
#                     [255,0,0],
#                     [0,255,0],
#                     [0,0,255],
#                     [255,255,255]])
# imagem = np.array([[0,1,2,0],
#                    [0,3,4,0]])
# print(palette[imagem])

# a = np.arange(12)*2; print(a)
# print(a[a<5])
# a[a<5] = 5
# a[a>5] = 15
# print(a)

# b = np.array([True, False])
# c = np.array([[1,2],[3,4]]);print(c)
# print(c[b,:])
# print(c[b,b])
# A = np.array([[1.,2.],[3.,4.]]); print(A)
# print(A.transpose())
# print(np.linalg.inv(A))
# print(A@A)
# print(np.trace(A))
# print(np.linalg.eig(print(A)))
# b = np.array([[5.],[7.]])
# print(np.linalg.solve(A,b)) # Ax=b


# MATPLOTLIB

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# t = np.linspace(0,2*np.pi,100)
# fig, ax = plt.subplots()
# ax.plot(t,np.sin(t))
# plt.show()

######## GRÁFICO DE LINHA #######

t = np.linspace(0,2*np.pi,100)
fig, ax = plt.subplots(2,2)
ax[0,0].plot(t,3*np.sin(t)); ax[0,0].set_title('Titulo do primeiro gráfico')
ax[1,0].plot(t,3*np.sin(t)); ax[1,0].set_title('Titulo do segundo gráfico')
ax[0,1].plot(t,3*np.sin(t)); ax[0,1].set_title('Titulo do terceiro gráfico')
ax[1,1].plot(t,3*np.sin(t)); ax[1,1].set_title('Titulo do quarto gráfico')
ax[1,1].set(xlim=(-2,2), ylim=(-4,4))
fig.tight_layout()
plt.show()

###### GRÁFICO DE BARRAS #######
N = 5
mediaHomens = (20,35,30,35,27)
mediaMulheres = (25, 25, 38, 15, 29)
stdHomens = (2,3,3,3,2)
stdMulheres = (0,5,0,5,7)
ind = np.arange(N)
width = 0.35
p1 = plt.bar(ind,mediaHomens,width, yerr=stdHomens)
p1 = plt.bar(ind,mediaMulheres,width, yerr=stdMulheres)
plt.ylabel('Pontuação'); plt.title('Pontuação por grupo e idade')
plt.xticks(ind,('G1', 'G2', 'G3', 'G4', 'G5'))
plt.yticks(np.arange(0,81,10))
plt.legend((p1[0],p2[0],("Homem ", "Mulher")))
plt.show()

###### GRÁFICO DE PIZZA ######

labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
size = [15,30,45,10]
fig,ax = plt.subplots()
ax.pie(size,labels=labels,shadow=True, explode=(0,0,0.1,0))
plt.show()

##### BOXPLOT ####

np.random.seed(19680801)
allData = [np.random.normal(0,std,size=100) for std in range(1,4)]
labels = ['x1','x2','x3']
fig,ax = plt.subplots(nrows=1,ncols=1, figsize=(9,4))
bplot = ax.boxplot(allData,vert=True,labels=labels)
plt.show()


##### HISTOGRAMA #####
np.random.seed(19680801)
N_points = 100000
n_bins = 20
x = np.random.randn(N_points)
fig,ax = plt.subplots(1,1)
ax.hist(x,n_bins)
plt.show()


### GRÁFICO 3D ###
np.random.seed(19680801)
fig = plt.figure()
ax = fig.gca(projection='3D')
x = np.random.sample(100)
z = np.random.sample(100)
y = np.random.sample(100)
ax.scatter(x,y,z)
plt.show()