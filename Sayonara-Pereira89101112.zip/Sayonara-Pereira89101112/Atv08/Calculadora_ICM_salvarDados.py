nome = input("Digite seu nome: ")

peso = float(input("Digite o seu peso: "))

altura = float(input("Digite sua altura: "))

IMC = peso/(altura**2)
print(IMC)
print(IMC < 18.5, "ICM abaixo da média, procure um especialista!"); print(18.5 < IMC < 25, "Parabéns! ICM normal!"); print(IMC > 25, "Alerta! ICM acima da média, procure um especialista.")

salvarDados = str(input('Deseja salvar os dados do IMC? Digite sim ou não.\n'))
if salvarDados == 'sim':
    print('Aguarde enquanto os dados serão processados!')
else:
    print('Fim do programa.')

formatoDados = str(input('Em que formato deseja que os dados sejam salvos? Digite 1 para csv ou 2 para txt: \n'))
if formatoDados == 2:
    experimentoCaixaDeSkinner = open('IMC.txt', 'w')
    experimentoCaixaDeSkinner.write(nome, peso, altura, IMC)
    experimentoCaixaDeSkinner.close()
else:
    import csv 
    with open('IMC.csv', 'w', newline='\n') as arquivo:
        spamwriter = csv.writer(arquivo, delimiter=',')
        spamwriter.writerow([nome])
        spamwriter.writerow([peso])
        spamwriter.writerow([altura])
        spamwriter.writerow([IMC])


print('Fim do programa.')