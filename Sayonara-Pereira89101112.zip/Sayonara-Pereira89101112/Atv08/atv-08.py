# problema na linha 38

import csv
import math

flexJoelho = open('Sayonara-Pereira\Atv08\coletaFlexJoelho.csv', 'r')

dados = []

for row in flexJoelho:
    dadosRaw = row.split('],""[')
    dadosRaw1 = dadosRaw[0].split('[')[1]
    dadosRaw2 = dadosRaw[1].split(']"""')[0]

    for dadosClean1 in dadosRaw1.split(","):
        dados.append(float(dadosClean1))
    for dadosClean2 in dadosRaw2.split(","):
        dados.append(float(dadosClean2))

print(dados)

def variaveisDeCalculo():
  ang = 0
  dadosCalculados = []

  for i in range(4,len(dados),4):
    ang = 0.98*(ang+dados[i]*0.05)+(1-0.98)*dados[i-3]
    dadosCalculados.append(ang)
  return variaveisDeCalculo

dadosFlexJoelhoTxt = open('FlexJoelho.txt', 'w')
print(dadosFlexJoelhoTxt)
dadosFlexJoelhoTxt.write("Estes são os dados FlexJoelho: ")
dadosFlexJoelhoTxt.write('dados')
dadosFlexJoelhoTxt.write('variaveisDeCalculo')
dadosFlexJoelhoTxt.close()

import csv
with open('DadosFlexJoelho.csv', 'w', newline='\n') as CalculoFlexJoelho:
  wr = csv.writer(variaveisDeCalculo, delimiter=',') # botei o spamwirter e o wr, mas continua pedindo uma "função" de escrita

dicionario = {}
dicionario['DadosFlexJoelho'] = {'Fórmula1':['(ax/math.sqrt(ay**2+az**2))*180/3.14'], 'Fórmula2':['0.98*(veloAngularX+dadow*0.05)+(1-0.98)*Fórmula1']}
print(dicionario)