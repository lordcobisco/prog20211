# MANIPULAÇÃO DE ARQUIVOS
'''termo geral para arquivar dados

diferentes tipos de armazenamentos de dados desempenham papeis diferentes em um ambiente de computação.

'''


# MANIPULAÇÃO DE ARQUIVOS TXT
'''um arquivo é categorizado como texto ou binário
- open
- read
- readline
- write
- close'''

# arquivoObjeto = open('nomeDoArquivo.txt', 'w')
# # print(arquivoObjeto)
# arquivoObjeto.write("Escrevendo a primeira linha do arquivo\n")
# arquivoObjeto.write('Escrevendo a segunda linha do arquivo\n')
# arquivoObjeto.close()

# outroArquivoObjeto = open('outroArquivo.txt', 'r')
# outroArquivoObjeto.write("Escrevendo a primeira linha do arquivo\n")
# outroArquivoObjeto.write('Escrevendo a segunda linha do arquivo\n')
# conteudoArquivo = outroArquivoObjeto.read()
# print(conteudoArquivo)
# for i in range(10):
#     conteudoArquivo = outroArquivoObjeto.read(i)
#     print(conteudoArquivo)

# conteudoArquivo = outroArquivoObjeto.readlines(1)
# lê as linhas do arquivo e transforma em uma lista
# print(conteudoArquivo)
# print(conteudoArquivo[:])

# maisArquivo = open('maisUm', 'w')
# lista = ['eu',' escrevo',' a lista',' toda', ' de', ' uma', ' vez']
# maisArquivo.writelines(lista)
# maisArquivo.close()
# maisArquivo = open('maisUm', 'r')
# for linha in maisArquivo:
#     print(linha)
# maisArquivo.close()

# with open('maisUm', 'r') as arquivo:
#     for line in maisArquivo:
#         print(line)
# print(maisArquivo.closed)

##### ARQUIVO CSV #####

# import csv
# with open('arquivocsv.csv', 'w', newline='\n') as arquivo:
#     spamwriter = csv.writer(arquivo, delimiter=',')
#     spamwriter.writerow(['escrevendo alguma coisa na linha'])
#     spamwriter.writerow([1,2,3,4])
#     spamreader = csv.reader(arquivo, delimiter=';')
#     for row in spamreader:
#         print(row)
#         for elemento in row:
#             print(int(elemento))



# import csv
# import math
# with open('Sayonara-Pereira\Atv08\coletaFlexJoelho.csv', 'rb') as flexJoelho:
#     spamreader = csv.reader(flexJoelho, delimiter=',')
#     for row in spamreader:
#         print(row)
#         # ax = row[0]
#         # ay = row[1]
#         # az = row[3]
#         # veloAngularX = row[4]
#         # dadow = row[5]
#         # dadoa = (ax/math.sqrt(ay**2+az**2))*180/3.14
#         # print(dadoa)
#         for elemento in row:
#             print(elemento)
