'''> MNE para leitura de dados MEG/EEG
# import os
# import numpy as np
# import mne

> scikit learn
> scikit-image'''

# pip install --user scikit-learn
# pip install --user scikit-image

# from sklearn.svm import SVC
# from sklearn.multiclass import OneVSRestClassifier
# from sklearn.preprocessing import LabelBinarizer

# X = [[1,2],[2,4],[4,5],[3,2],[3,1]]
# y = [0,0,1,1,2]
# classif = OneVSRestClassifier(estimator=SVC(gamma='scale', random_state=0))
# modeloTreinado = classif.fit(X,y)
# yEstimado = modeloTreinado.predict(X)
# print(y,yEstimado,y==yEstimado)

# X = [[4,2], [7,4], [4,9], [3,3], [3,0]]
# y = [1,8,1,3,2]
# yestimado = modeloTreinado.predict(X)
# print(y,yestimado,y==yestimado)

# from typing import Counter
# from sklearn import svm
# from sklearn.datasets import load_digits
# import matplotlib.pyplot as plt

# digits = load_digits()
# # plt.gray()
# # for imagens in digits.images:
# #     plt.matshow(imagens)
# #     plt.show()
# classif = svm.SVC(gamma=0.001, c=100.)
# modeloTreinado = classif.fit(digits.data[:-1],digits.target[:-1])
# predict = modeloTreinado.predict(digits.data[:-1])
# print(predict)

# for imagens in digits.images:
#     plt.matshow(imagens)
#     plt.show()
# modeloTreinado.predict(imagens[:-1])

# # images_and_predictions = list(zip(digits.images[-1:],predict))
# # for index,(image,prediction) in enumerate(images_and_predictions):
# #     plt.axis('off')
# #     plt.imshow(image)
# #     print(predict[counter])
# #     counter += 1


# images_and_predictions = list(zip(digits.images[-1:], predict))
# counter = 0
# for image in digits.images:
#     plt.axis('off')
#     plt.imshow(image)
#     print(predict[counter])
#     counter += 1

# from sklearn import svm
# from sklearn import datasets
# classif = svm.SVC(gamma='scale')
# iris = datasets.load_iris()
# X, y = iris.data, iris.target
# modeloTreinado = classif.fit(X,y)
# print(y[51])

# from joblib import dump, load
# dump(modeloTreinado,'modeloTreinado.mod')

# clf = load('modeloTreinado.mod')
# print(clf.predict([X[51]]))


#######################################################################
import skimage as skimage
from skimage import data, io, filters

imagem = data.coins()
io.imshow(imagem)
io.show()

bordas = filters.sobel(imagem)
io.imshow(bordas)
io.show()

import matplotlib.pyplot as plt
from skimage.restoration import denoise_tv_chambolle, denoise_bilateral, denoise_wavelet, estimate_sigma
from skimage import data, img_as_float
from skimage.util import random_noise

original = img_as_float(data.chelsea()[100:250,50:300])
sigma = 0.155
noisyImage = random_noise(original,var = sigma**2)

fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(8,5))
plt.gray()

sigma_est = estimate_sigma(noisyImage, multichannel=True, average_simas=True)
print("Sigma estimado: {}".format(sigma_est) )

ax[0].imshow(noisyImage, multichannel=True)
ax[0].axis('off')
ax[0].set_title('NoisyImage')

ax[1].imshow(denoise_tv_chambolle(noisyImage, weight=0.1, multichannel=True))
ax[1].axis('off')
ax[1].set_title('TV')

ax[2].imshow(denoise_bilateral(noisyImage, multichannel=True))
ax[2].axis('off')
ax[2].set_title('TV')

ax[3].imshow(denoise_wavelet(noisyImage, multichannel=True, convert2ycbcr=True))
ax[3].axis('off')
ax[3].set_title('Original')
fig.tight_layout()
plt.show()

import numpy as np
import matplotlib.pyplot as plt
from skimage import data
from skimage.feature import match_template

imagem = data.coins()
coin = imagem[170:220, 75:130]

resultado = match_template(imagem, coin)
ij = np.unravel_index(np.argmax(resultado), resultado.shape)
x,y = ij[::-1]
fig = plt.figure(figsize=(8,3))
ax1 = plt.subplot(1,3,1)
ax2 = plt.subplot(1,3,2)
ax3 = plt.subplot(1,3,3)

ax1.imshow(coin, cmap=plt.cm.gray)

ax2.imshow(imagem, cmap=plt.cm.gray)
hcoin,wcoin = coin.shape
retangulo = plt.Rectangle((x,y), wcoin, hcoin, edgecolor='r', facecolor='none')
ax2.add_patch(retangulo)

ax3.imshow(resultado)
ax3.plot(x,y,'o',markeredgecolor='r',markerfacecolor='none',markesize=10)
plt.show()