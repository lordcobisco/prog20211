'''
Deve ser possível regular o tempo de experimento e configurar em quais momentos os leds de cada dispositivo 
vão acionar.
Deve ser possível parar o experimento a qualquer momento do experimento caso algo aconteça de errado.
Deve ser possível registrar múltiplas sessões simultâneas (experimentos diferentes não correlacionados temporalmente, 
mas que ocorrem ao mesmo tempo).

 O programa deve conter:

Estrutura de repetição
Temporização (Esse item deve ser pesquisado, ou seja, buscar uma solução na rede)'''


print('Bem vindo(a) a estimulação optogenética! \n Daremos início às configurações. \n')

red = input('Digite a intensidade da cor vermelha: \n')
green = input('Digite a intensidade da cor verde: \n')
blue = input('Digite a intensidade da cor azul: \n')

red2 = input('Digite a intensidade da cor vermelha do segundo dispositivo: \n')
green2 = input('Digite a intensidade da cor verde do segundo dispositivo: \n')
blue2 = input('Digite a intensidade da cor azul do segundo dispositivo: \n')


from threading import Timer
 
def inicioExperimento():
  print("Os experimentos começarão em 2 segundos! \n", red, red2)
t = Timer(2.0, inicioExperimento)
t.start()

# import time
# first_time = time.time()
# time.sleep(0)
# second_time = time.time()
# diferenca_tempo = second_time - first_time
# print ("Vamos começar os experimentos!",(int(diferenca_tempo)))

matrizEletrodos = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32]

ledRGB = [red,green,blue, matrizEletrodos]
ledRGB2 = [red,green,blue, matrizEletrodos]

for matrizEletrodos,ledRGB in zip(matrizEletrodos,ledRGB):
    print(matrizEletrodos,ledRGB)

dispositivo1 = [ledRGB]
dispositivo2 = [ledRGB2]
for experimento1,experimento2 in zip(dispositivo1,dispositivo2):
    print(dispositivo1,dispositivo2)

def setLedsR(ledVermelho = int(input('O led vermelho está acionado? \n Digite 0 para não ou 1 para sim: \n'))):
    if ledVermelho:
        print(red)
    else:
        print('Continue para configurar o próximo led. \n')

alterarIntensidade = int(input('Deseja alterar essa intensidade? \n Digite 0 para não ou 1 para sim: \n'))
if alterarIntensidade:
    print(input("Digite um novo valor para intensidade da luz vermelha: \n"))
else:
    print('Seguiremos para cor verde! \n')

def setLedsG(ledVerde = int(input('O led verde está acionado? \n Digite 0 para não ou 1 para sim: \n'))):
    if ledVerde:
        print(green)
    else:
        print('Continue para configurar o próximo led. \n')

alterarIntensidade1 = input('Deseja alterar essa intensidade? \n Digite 0 para não ou 1 para sim: \n')
if alterarIntensidade1:
    print(input("Digite um novo valor para intensidade da luz verde: \n"))
else:
    print('Seguiremos para cor azul! \n')

def setLedsB(ledAzul = int(input('O led azul está acionado? \n Digite 0 para não ou 1 para sim: \n'))):
    if ledAzul:
        print(blue)
    else:
        print('Leds configurados! \n')
alterarIntensidade2 = input('Deseja alterar essa intensidade? \n Digite 0 para não ou 1 para sim: \n')
if alterarIntensidade2:
    print(input("Digite um novo valor para intensidade da luz azul: \n"))
else:
    print('Leds configurados! \n')
