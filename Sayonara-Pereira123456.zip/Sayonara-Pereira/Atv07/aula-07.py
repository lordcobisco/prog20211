# FUNÇÕES E CLASSE

'''blocos de códigos organizados e reutilizáveis para realizar uma única ação.
Permitem maior modularização para a aplicação e alto grau de reutilização de código.'''

# SINTAXE

'''def functionName ():

functionName ()'''

def funcaoExemplo():

    return

    # OU 

# def funcaoExemplo2(entrada1,entrada2, entrada3, entradan=9):

#     return entrada1, entrada2, entrada3, entradan

# '''Possui 2 fases: criação (declaração: nome, entradas, saídas) e utilização.'''

# print (funcaoExemplo2(1,2,3,4))

# retornoFuncao = (funcaoExemplo2([1,2],3,4))
# print(retornoFuncao[0])

# retornoFuncao1,retornoFuncao2 = funcaoExemplo2(1,2,3,4)
# print(retornoFuncao1,retornoFuncao2)

# retornoFuncao3 = funcaoExemplo2(entrada1=[1,2,3,4,5])
# print(retornoFuncao3)

# def mensagem_de_erro():
#     '''não há retorno nesta função, apenas uma mensagem de erro'''
# print('ERROR')

# erro = bool(int(input('Deu erro?')))
# if erro == True:
#     mensagem_de_erro()


# def low_pass_filter(raw_data,filter_parameter = 0.1):
#     filtered_data = []
#     for i in range(len(raw_data)):
#         if i == 0:
#             filtered_data.append(raw_data[i])
#         else:
#             filtered_data.append(filtered_data[i-1] + filter_parameter*(raw_data[i]-filtered_data[i-1]))
#     return filtered_data

# print(low_pass_filter([1,2,3,4,5,6,7,8,9,10]))

# '''variáveis declaradas dentro de uma função só existem dentro da função'''

# def myFunc():
#     x = 10
#     print('Value inside function: ',x)

# x = 20
# myFunc()
# print('Value outside function: ', x)

# def function(country = Brazil):
#     print('I am from: ')

# function(Canada)
# function()
# function(Norway)

# def funcaoRecursiva(k):
#     if(k>0):
#         result = k + funcaoRecursiva(k-1)
#         print(result)
#     else: 
#         result = 0
#     return 
    
# print(funcaoRecursiva(6))


## INTRODUÇÃO A CLASSE ##
'''padrão para definição de objetos (descreve que propriedades ou atributos o objeto terá
exemplos: int, list, tuple'''
