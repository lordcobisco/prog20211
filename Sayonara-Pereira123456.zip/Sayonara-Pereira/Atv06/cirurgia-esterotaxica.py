print('Bem vindo ao software de cirurgia esterotáxica. Daremos inicio aos procedimentos!')

peso = input('Digite o peso do animal: \n')

anestesiaConjunto = ('ketamina', 'xilazina')
anestesia = [anestesiaConjunto, 'halotano']

for anestesiaConjunto,anestesia in (anestesia,anestesiaConjunto):
     print(anestesia,(input('Digite o anestésico e a dosagem que será utilizada: \n')))

print('O procedimento anestésico está definido! Aguarde até que o anestésico tenha efeito. \n')

efeitoAnestesico = int(input('Verifique se o animal está acordado.\n Aperte 0 caso o anestésico ainda não tenha surgido efeito, ou 1 caso o animal já esteja sob efeito. \n'))
if efeitoAnestesico:
    print('Daremos seguimento à cirurgia.\n')
else:
    print('Aguarde até que o animal esteja desacordado.\n')

print('Posicione o animal no estereotáxico!\n Verifique se as barras estão posicionadas no ouvido externo do sujeito experimental.\n')

angulacao = int(input('Verifique se há diferenças de angulação entre o bregma e o lambda.\n Aperte 0 caso haja diferenças de angulação, ou 1 caso não haja diferenças de angulação. \n'))
if efeitoAnestesico:
    print('Daremos seguimento à cirurgia.\n')
else:
    print('Regule a angulação do animal.\n')

print('Seguiremos para limpeza do campo de trabalho! \n')

pelagem = int(input('Retire a pelagem que recobre a parte superior da calota craniana! \n Digite 1 para pelagem totalmente retirada, 2 para pelagem parcialmente retirada, ou 3 para pelagem não retirada.\n'))
if pelagem == 1:
    print('Seguiremos para o próximo passo!\n')
elif pelagem == 2:
    print('Retire a pelagem totalmete!\n')
elif pelagem == 3:
    print('Inicie o procedimento de tirada da pelagem! \n')
else:
    print('Digite um número válido!\n')

print('Pelagem retirada! Seguiremos para a retirada dos tecidos moles. \n')

tecidosMoles = (int(input('Inicie a retirada dos tecidos moles! Digite 1 para já alcançou a parte óssea ou 2 se ainda não tiver alcançado.\n')))
while tecidosMoles == 1:
    print('Continue até alcançar a parte óssea da caixa craniana. \n')
    tecidosMoles +=1
    if tecidosMoles == 2:
        print('Seguiremos para limpeza da calota craniana. \n')
    break

limpezaCalota = input('Você realizou a limpeza total da calota craniana? (digite sim ou não) \n')
if limpezaCalota == 'sim':
    print('Aplique uma pequena camada de poliacrilato em todo o perímetro externo. \n ')
else:
    print('Siga todos os passos para limpeza do campo. \n')


print('Parabéns! A limpeza do campo de trabalho está pronta. Seguiremos para fixação de parafusos. \n')

fixacaoParafusos = input('Escolha um ponto para a fixação de parafusos. Digite 1 para parafusos grandes.\n')
if fixacaoParafusos == 1:
    print('Dê até 3 voltas no parafuso')
else:
    print('Siga para o posicionamento das agulhas.')

print('Os parafusos foram fixados! Vamos iniciar o cálculo para posicionamento da agulha.')

anteroPosterior = float(input('Digite o valor encontrado na régua para posicionamento antero posterior. \n'))
lateroLateral = float(input('Digite o valor encontrado na régua para posicionamento latero lateral. \n'))
dorsoVentral = float(input('Digite o valor encontrado na régua para posicionamento dorso ventral. \n'))

posicaoAgulha = [anteroPosterior - 0.42, lateroLateral - 0.30, lateroLateral + 0.30, dorsoVentral - 0.2]
print('Este é o posicionamento, respectivamente, antero posterior, latero lateral-, latero lateral+. dorso ventral: \n',posicaoAgulha)

localizacaoPontos = int(input('Os pontos foram localizados?\n digite 0 para não e 1 para sim.\n'))
if localizacaoPontos:
    print('Faça furos para introdução das cânulas-guia.\n')
else:
    print('Localize os pontos indicados acima. \n')

grauAngulacao = int(input('Digite o grau de angulação da broca contra o assoalho\n'))
if grauAngulacao == 45:
    print('Inicie a perfuração!\n')
else:
    print('Certifique-se que a agunlação encontra-se em 45º!\n')

meninge = int(input('Perfure com a broca até alcançar as meninges.\n Atenção! As meninges não devem ser perfuradas! \n  Digite 5 quando estas forem alcançadas.'))
for i in range(5):
    print(i, meninge)

print('Perfuração finalizada! Seguiremos para introdução da cânula-guia. \n')
print('Introduza a cânula-guia até o valor dorso ventral definido anteriormente.zn')

drenagemSanguinea = input('Faça a drenagem de sangue ou líquido cefalorraquidiano utilizando pequenos rolos de papel absorvente. \n Digite 0 para drenagem não realizada ou 1 para drenagem completa. \n')
if drenagemSanguinea:
    print('Siga para o próximo passo!\n')
else:
    print('Realize a drenagem!\n')

print('Drenagem concluida! Siga para mistura do acrílico polimerizante!\n')

acrilicoPolimerizanteSeco = int(input('Misture o acrílico polimerizante com o solvente até obter textura espessa e maleável. \n Com essa mistura faça um capacete abrangendo o crânio, a cânula-guia e o parafuso. Deixe secar até ficar suficientemente rígido. \n Digite 0 caso a mistura não esteja seca ou 1 caso a mistura esteja completamente seca. \n'))
if acrilicoPolimerizanteSeco:
    print('Seguiremos para o próximo passo! \n')
else:
    print('Aguarde até que a mistura esteja completamente seca. \n')

print('Secagem completa! Seguiremos para fixação da segunda cânula-guia. \n Introduza-a cuidadosamente até o valor dorso ventral definido anteriormente. \n')

drenagemSegundaCanula = input('Faça a drenagem de sangue ou líquido cefalorraquidiano utilizando pequenos rolos de papel absorvente. \n Digite 0 para drenagem não realizada ou 1 para drenagem completa. \n')
if drenagemSegundaCanula:
    print('Siga para o próximo passo!\n')
else:
    print('Realize a drenagem!\n')

print('Drenagem concluida! Siga para mistura do acrílico polimerizante!\n')

acrilicoPolimerizanteSeco2 = int(input('Misture o acrílico polimerizante com o solvente até obter textura espessa e maleável. \n Com essa mistura faça um capacete abrangendo o crânio, a cânula-guia e o parafuso. Deixe secar até ficar suficientemente rígido. \n Certifique-se de deixar um espaço entre o capacete e o início da área tecidual Digite 0 caso a mistura não esteja seca ou 1 caso a mistura esteja completamente seca. \n'))
if acrilicoPolimerizanteSeco2:
    print('Seguiremos para o próximo passo! \n')
else:
    print('Aguarde até que a mistura esteja completamente seca. \n')

print('Drenagem e aplicação do acrílico polimerizante concluidos!\n Acomode o animal em uma caixa aquecida por uuma lâmpada e sem outros animais acordados.')

animalAcordado = int(input('O animal acordou? Digite 0 para não ou 1 para sim. \n'))
if animalAcordado:
    print('Coloque o animal de volta a sua caixa-moradia.\n')
else:
    print('Aguarde até que o animal acorde para devolvê-lo à sua caixa-moradia. \n')


dicionario = {}
dicionario['Cirurgia Esterotaxica'] = {'peso':['peso do animal'], 'anestesia':['ketamina', 'xilazina', 'halotano'], 'efeitoAnestesico' : ['sim', 'não'], 'angulacao':[45], 'pelagem':['tosado', 'não tosado'], 'tecidosMoles':['retirada'], 'limpezaCalota':['completa', 'incompleta'], 'fixacaoParafusos':['grande', 'pequeno'], 'posicaoAgulha':['dorso ventral', 'latero lateral', 'antero posterior'], 'drenagemSanguinea':['completa', 'incompleta'], 'acrilicoPolimerizanteSeco':['mistura realizada', 'mistura não realizada']}

print(dicionario['Cirurgia Esterotaxica'])
procedimentos = int(input('Todos os procedimentos acima descritos foram realiados? Digite 0 para não ou 1 para sim: \n'))
if procedimentos:
    print('A cirurgia chegou ao fim! Parabéns!\n')
else:
    print('Siga corretamente todos os procedimentos indicados!\n')

print('Fim do programa! Até a próxima :)')