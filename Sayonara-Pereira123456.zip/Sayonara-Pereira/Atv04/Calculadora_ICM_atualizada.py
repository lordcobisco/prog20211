nome = input("Digite seu nome: ")

peso = float(input("Digite o seu peso: "))

altura = float(input("Digite sua altura: "))

IMC = peso/(altura**2)
if IMC < 17:
    print("IMC muit abaixo da média, procure um especialista!\n")
elif IMC > 17 > 18.5:
    print('Alerta! IMC abaixo da média.\n')
elif IMC > 18.5 > 25: 
    print('IMC normal')
elif IMC > 25 > 30:
    print('Alerta! IMC acima da média\n')
elif IMC > 30:
    print("IMC muito acima da média! Procure um especialista.\n")
else:
    print('Insira um número válido')