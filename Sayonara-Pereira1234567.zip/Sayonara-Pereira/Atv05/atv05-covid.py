#codigos de saúde não disponíveis no arquivo, substitui por regiões do Brasil
#dados referentes ao dia 25/08/2021

print('Bem vindo a página de informações a respeito do COVID-19\n')

norte = ['AC', 'AM', 'PA', 'RR', 'RO', 'TO', 'AP']
nordeste = ['BA', 'CE', 'RN', 'PB', 'PI', 'MA', 'AL', 'SE', 'PE']
sul = ['RS', 'SC', 'PR']
sudeste = ['SP', 'RJ', 'ES', 'MG']
centroOeste = ['GO', 'MT', 'MS', 'DF']

norteTupla = ('AC', 'AM', 'PA', 'RR', 'RO', 'TO', 'AP')
nordesteTupla = ('BA', 'CE', 'RN', 'PB', 'PI', 'MA', 'AL', 'SE', 'PE')
sulTupla = ('RS', 'SC', 'PR')
sudesteTupla = ('SP', 'RJ', 'ES', 'MG')
centroOesteTupla = ('GO', 'MT', 'MS', 'DF')

casosAcumuladosTuplaRJ = (sudesteTupla[1], 1116338)

casosAcumuladosNorte = [norte[4], 262411, 
                       norte[0], 8779, 
                       norte[1], 423524, 
                       norte[2], 581788, 
                       norte[3], 123121, 
                       norte[6], 122333, 
                       norte[5], 217396]
casosAcumuladosNordeste = [nordeste[0], 1216546, 
                           nordeste[1], 929670, 
                           nordeste[2], 364406, 
                           nordeste[3], 431090, 
                           nordeste[4], 315337, 
                           nordeste[5], 347057, 
                           nordeste[6], 234729, 
                           nordeste[7], 277283, 
                           nordeste[8], 604991]
casosAcumuladosSul = [sul[0], 1403339, 
                      sul[1], 1148649, 
                      sul[2], 1447855]
casosAcumuladosSudeste = [sudeste[0], 4229600, 
                          sudeste[1], 1116338, 
                          sudeste[2], 558720, 
                          sudeste[3], 2051177]
casosAcumuladosCentroOeste = [centroOeste[0], 805103, 
                              centroOeste[1], 512036, 
                              centroOeste[2], 367015, 
                              centroOeste[3], 466294]

obitosAcumuladosNorte = [norte[4], 1813, 
                         norte[0], 13669, 
                         norte[1], 16404, 
                         norte[2], 1933, 
                         norte[3], 6470, 
                         norte[6], 3664, 
                         norte[5], 1949]
obitosAcumuladosNordeste = [nordeste[0], 26332, 
                            nordeste[1], 23979, 
                            nordeste[2], 7255, 
                            nordeste[3], 9154, 
                            nordeste[4], 6936, 
                            nordeste[5], 9946, 
                            nordeste[6], 6036, 
                            nordeste[7], 5975, 
                            nordeste[8], 19329]
obitosAcumuladosSul = [sul[0], 34056, 
                       sul[1], 18581, 
                       sul[2], 37178]
obitosAcumuladosSudeste = [sudeste[0], 144767, 
                           sudeste[1], 61752, 
                           sudeste[2], 12174, 
                           sudeste[3], 52626]
obitosAcumuladosCentroOeste = [centroOeste[0], 22230, 
                               centroOeste[1], 13163, 
                               centroOeste[2], 9308, 
                               centroOeste[3], 9966]

NovosObitosNorte = [norte[4], 2, 
                         norte[0], 8, 
                         norte[1], 14, 
                         norte[2], 5, 
                         norte[3], 6, 
                         norte[6], 4, 
                         norte[5], 0]
NovosObitosNordeste = [nordeste[0], 25, 
                            nordeste[1], 4, 
                            nordeste[2], 5, 
                            nordeste[3], 5, 
                            nordeste[4], 4, 
                            nordeste[5], 27, 
                            nordeste[6], 6, 
                            nordeste[7], 3, 
                            nordeste[8], 15]
NovosObitosSul = [sul[0], 45, 
                       sul[1], 23, 
                       sul[2], 80]
NovosObitosSudeste = [sudeste[0], 257, 
                           sudeste[1], 147, 
                           sudeste[2], 14, 
                           sudeste[3], 105]
NovosObitosCentroOeste = [centroOeste[0], 45, 
                               centroOeste[1], 24, 
                               centroOeste[2], 28, 
                               centroOeste[3], 18]


NovosObitosNordeste = [nordeste[0], 25, 
                            nordeste[1], 4, 
                            nordeste[2], 5, 
                            nordeste[3], 0, 
                            nordeste[4], 4, 
                            nordeste[5], 27, 
                            nordeste[6], 6, 
                            nordeste[7], 3, 
                            nordeste[8], 15]


NovosObitosNorteTupla = (norte[4], 2, 
                         norte[0], 8, 
                         norte[1], 14, 
                         norte[2], 5, 
                         norte[3], 6, 
                         norte[6], 4, 
                         norte[5], 0)
NovosObitosNordesteTupla = (nordeste[0], 25, 
                            nordeste[1], 4, 
                            nordeste[2], 5, 
                            nordeste[3], 5, 
                            nordeste[4], 4, 
                            nordeste[5], 27, 
                            nordeste[6], 6, 
                            nordeste[7], 3, 
                            nordeste[8], 15)
NovosObitosSulTupla = (sul[0], 45, 
                       sul[1], 23, 
                       sul[2], 80)
NovosObitosSudesteTupla =(sudeste[0], 257, 
                           sudeste[1], 147, 
                           sudeste[2], 14, 
                           sudeste[3], 105)
NovosObitosCentroOesteTupla = (centroOeste[0], 45, 
                               centroOeste[1], 24, 
                               centroOeste[2], 28, 
                               centroOeste[3], 18)


NovosObitosNordesteTupla = (nordeste[0], 25, 
                            nordeste[1], 4, 
                            nordeste[2], 5, 
                            nordeste[3], 0, 
                            nordeste[4], 4, 
                            nordeste[5], 27, 
                            nordeste[6], 6, 
                            nordeste[7], 3, 
                            nordeste[8], 15)




print('O dado NovosObitos correto para o Estado da Paraíba é:\n', NovosObitosNordeste[6:8])
#não é possível sobrescrever uma Tupla

print(('Este é o número de casos acumulados no Estado solicitado: \n'), sudeste[1], casosAcumuladosSudeste[3])
print(('Este é o número de casos guardado em uma Tupla: \n'), casosAcumuladosTuplaRJ)
print('Este é o total de óbitos acumulados por Estado:\n', obitosAcumuladosNordeste, obitosAcumuladosCentroOeste, obitosAcumuladosNorte, obitosAcumuladosSudeste, obitosAcumuladosSul)

Roraima = ['Amajari', [1157, 21, 0], 
           'Alto Alegre', [1579, 36, 0], 
           'Boa Vista', [95051, 1474, 5], 
           'Bonfim', [2471, 33, 0],
           'Cantá', [2429,38,0], 
           'Caracaraí', [2678, 56,0], 
           'Caroebe', [1978,21,0], 
           'Iracema', [1273, 15,0], 
           'Mucajaí',[2284,41,0],
           'Normandina',[543,25,0],
           'Pacaraima',[2321,45,0],
           'Rorainópolis',[3253,66,0],
           'São João da Baliza', [1605,11,0],
           'São Luiz',[659,12,0],
           'Uiramutã',[1180,15,0]]


norte.append([Roraima])
print('\nEstes são os municípios de Roraima, como número de casos acumulados, número de óbitos acumulados e novos casos, respectivamente: \n',norte)

DadosRoraima2021 = [123121, 6470, 6]
DadosRoraima2020 = [40183, 574, 6]


if sum(DadosRoraima2021) == sum(DadosRoraima2020):
    print('A soma dos dados é igual\n', sum(DadosRoraima2020))
else:
    print('\nA soma dos dados não é igual\n')
print(('O tamanho das listas é de: \n'), len(DadosRoraima2020), ' e ', len(DadosRoraima2021))

NovosObitos = [2, 8,  14,  5, 6, 4, 0, 25,  4, 5, 5, 4,27, 6, 3, 15,23, 80, 257, 147, 14, 105, 45, 24, 28, 18]

print(('O maior valor numérico de novos óbitos é de: \n'), max(NovosObitos))
print(('O menor valor numérico de novos óbitos é de: \n'), min(NovosObitos))

dicionario = {}
dicionario['dadosCOVID'] = {'casos acumulados':[casosAcumuladosNorte, casosAcumuladosCentroOeste, casosAcumuladosNordeste, casosAcumuladosSudeste, casosAcumuladosSul], 
                            'óbitos acumulados':[obitosAcumuladosSul, obitosAcumuladosCentroOeste, obitosAcumuladosNorte, obitosAcumuladosNordeste, obitosAcumuladosSudeste],
                            'novos óbitos':[NovosObitosCentroOeste, NovosObitosNordeste, NovosObitosNorte, NovosObitosSudeste, NovosObitosSul]}

Teresina = ['Casos Acumulados', 104274, 'Óbitos acumulados', 2532, 'Novos óbitos', 0]
print(('Esta é a quantidade de novos casos em Teresina para o dia 25/08/2021: \n'), Teresina[4:6])