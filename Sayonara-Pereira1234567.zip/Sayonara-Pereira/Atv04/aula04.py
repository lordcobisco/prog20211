
'''Aula 04 sobre if, else e elif'''
# false and false = false
# true and false = false
# false and true = false
# true and true = true 


#boato1Apertado = int(input("Digite 0 caso o botão 1 tenha sido apertado ou 1 caso não tenha sido apertado: "))
#botao2Apertado = int(input("Digite 0 caso o botão 2 tenha sido apertado oou 1 caso não tenha sido apertado: "))

#if boato1Apertado == 0 and (not botao2Apertado):
 #   print("Enriqueça o ambiente experimental!")



#variavelLogica = int(input("Digite um número inteiro \n entre 1 e 10: "))

#if variavelLogica >= 5:
    #print("You did great!")

#if sozinho

#if 3 == 2+1:
 #   print("Sayonara")
  #  print("Cuidado com os erros de sintaxe!")

'''IF E ELSE

0 = falso
1 = verdadeiro (padrão)

voceEInteligente = int(input("Você é inteligente? \n"))

if voceEInteligente:
    print("Você é inteligente\n")
else:
    print("Você não é inteligente")

numeroMenor = int(input("Digite um número menor que 5: "))

if numeroMenor < 5:
    print("O número digitado foi: " , numeroMenor)
else:
    print("Ops! \n Numéro maior que 5, tente novamente mais tarde.")'''

print("Menu de seleção")
acao = int(input("Digite 1 para acessar histórico escolar e 2 para acessar declaração: "))
if acao == 1:
    print("Seu histórico foi enviado! \n")
elif acao == 2:
    print("Sua declaração foi enviada! \n")
else:
    print("Escolha uma das duas opções!")

