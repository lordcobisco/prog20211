print('Bem vindo a caixa de condicionamento operante!')

habituacao = int(input('Digite 0 se esta for uma sessão de habituação, ou 1 caso o animal já esteja habituado\n'))

if habituacao:
    print('Seguiremos para treino de aproximação')
else: 
    print('Coloque marshmellows na caixa')

distancia = 30
iniciarTreino = float(input('Qual a distância entre o animal e a barra?\n'))
if iniciarTreino >= distancia:
    print("Vamos iniciar o treinamento!\n")
else:
    print('Aguarde até que o animal esteja a, pelo menos, 30cm da barra\n')

aproximacao = int(input('O animal aproximou-se da barra?\n 0 NÃO / 1 SIM\n'))
if aproximacao:
    print('Liberar 0,5ml de rec\n')
else:
    print('Aguardar aproximação\n')


toqueBarra = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra1 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra1:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra1 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra2 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra2:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra2 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra3 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra3:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra3 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')


toqueBarra4 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra4:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra4 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra5 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra5:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra5 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra6 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra6:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra6 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra7 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra7:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra7 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra8 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra8:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra8 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra9 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra9:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra9 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra10 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra10:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra10 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra11 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra11:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra11 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra12 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra12:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra12 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra13 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra13:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra13 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')


toqueBarra14 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra14:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra14 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra15 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra15:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra15 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra16 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra16:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra16 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra17 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra17:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra17 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra18 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra18:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra18 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra19 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra19:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra19 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')

toqueBarra20 = int(input('O animal tocou a barra? \n0 NÃO 1 SIM\n'))
if toqueBarra20:
    print(int(input('Quantas vezes o animal tocou a barra?\n')))
elif toqueBarra20 >= 20:
    print('Parabéns! Passamos para a próxima etapa do experimento.\n')
else:
    print('Aguarde até que o animal toque a barra.\n')


condicionamentoAuditivo = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo and barraEsquerda:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo1 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda1 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo1 and barraEsquerda1:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo2 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda2 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo2 and barraEsquerda2:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo3 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda3 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo3 and barraEsquerda3:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo4 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda4 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo4 and barraEsquerda4:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo5 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda5 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo5 and barraEsquerda5:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo6 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda6 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo6 and barraEsquerda6:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo7 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda7 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo7 and barraEsquerda7:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo8 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda8 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo8 and barraEsquerda8:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo9 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda9 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo9 and barraEsquerda9:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo10 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda10 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo10 and barraEsquerda10:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo11 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda11 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo11 and barraEsquerda11:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo12 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda12 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo12 and barraEsquerda12:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo13 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda13 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo13 and barraEsquerda13:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo and barraEsquerda:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo1 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda1 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo1 and barraEsquerda1:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo2 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda2 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo2 and barraEsquerda2:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo3 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda3 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo3 and barraEsquerda3:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo4 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda4 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo4 and barraEsquerda4:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo5 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda5 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo5 and barraEsquerda5:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo6 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda6 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo6 and barraEsquerda6:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo7 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda7 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo7 and barraEsquerda7:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo8 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda8 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo8 and barraEsquerda8:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo9 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda9 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo9 and barraEsquerda9:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo10 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda10 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo10 and barraEsquerda10:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo11 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda11 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo11 and barraEsquerda11:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo12 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda12 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo12 and barraEsquerda12:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo13 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda13 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo13 and barraEsquerda13:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivo14 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda14 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo14 and barraEsquerda14:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivo15 = int(input('O som1 foi emitido?\n 0 NÃO 1 SIM\n'))
barraEsquerda15 = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivo15 and barraEsquerda15:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')


condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')
condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')
condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')
condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')
condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

condicionamentoAuditivoDireito = int(input('O som2 foi emitido?\n 0 NÃO 1 SIM\n'))
barraDireita = int(input('A barra esquerda foi apertada seguida do som1?\n 0 NÃO 1 SIM\n'))
if condicionamentoAuditivoDireito and barraDireita:
    print('Liberar 0,5 de rec\n')
else: 
    print('Não liberar recompensa.\n')

experimento = int(input('Quantas vezes o experimento foi realizado nos últimos 30 minutos?\n'))
if experimento < 50:
    print('O experimento deve ocorrer, minimamente, por 50 vezes.\n')
elif experimento > 50:
    print('Siga para a próxima fase do estudo.\n')
