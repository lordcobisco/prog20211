# lista = [1,2,3,4,5,6,7,8]

# for conteudoLista in lista: # pegue o conteudo da lista um a um e coloque na variavel conteudolista até que você chegue no final da lista
#       print(conteudoLista)
# lista1 = [6,7,8,9,1,2,3,4,5,]
# lista2 = [1,2,3,4,5]
# for i in range(5):
#     print(i, lista1[i+4],lista2[i])
# print('Fim de programa')

# lista1 = [6,7,8,9,1,2,3,4,5,]
# lista2 = [1,2,3,4,5]
# for i in range(3,5,1):
#     print(i, lista1[i+4],lista2[i])

# print('Fim de programa')

# listaGenereica = [1, 1.4, 'Yago',
#                   [1, 2, 'Daniel'],
#                   {'chave':'conteudo'}]
# for conteudoLista in listaGenereica:
#     print(conteudoLista)

# listaRange = range(5)
# print(listaRange)
# for i in range(5):
#     conteudoLista = listaGenereica[i]
#     print(conteudoLista)

# dicionario = {'head':[1,2,3,4,5],
#               'spine_01' :[1,2,3,4,5,5],
#               'calf_r':[1,2,3,4,5,6,7,8,9]}
# for chave in dadosDeIMU:
#     print(chave, dadosDeIMU[chave])


# covid = {'Brasil':
#             {'Nordeste':
#                  {'RN':
#                    {'Macaíba':
#                        {'ObitosAcumulados':[1,2,3,4,5,6,7,8,9]
#                        }
#                     }
#                  },
#             'Paraíba':
#                 {'PB':
#                     {'João Pessoa':
#                        {'ObitosAcumulados':[1,2,3,4,5,6,7,8,9]
#                        }
#                     },
#             'Norte':
#                  {'AM':
#                    {'Manaus':
#                        {'ObitosAcumulados':[1,2,3,4,5,6,7,8,9]
#                        }
#                     }
#                 }
#             }
#         }
# }
# for regiao in covid['Brasil']:
#     print(regiao)
#     for estado in covid['Brasil'][regiao]:
#         print(estado)

# comidas = ['bacon', 'fritas', 'picanha']
# bebidas = ['cerveja', 'refri', 'suco']
# for comida,bebida in zip(comidas,bebidas):
#     print(comida,bebida)



# condição = bool(int(input('Digite 0 ou 1')))
# while condição:
#     print('Entrou pq a condição é verdadeira')
#     condição = bool(int(input('Digite 0 ou 1\n')))

# contador = 0
# while contador < 5:
#     print(contador)
#     # contador = contador + 1
#     contador +=1
#     if contador == 3:
#         break

dados_covid = [[1,2,3,4,5,6],[7,8,9,10,0,1]]
contador = 0
while True:
    if sum(dados_covid[contador]) >= 25:
        contador +=1
        continue
    print(dados_covid[contador])
    # contador = contador + 1
    contador +=1
    if contador == 3:
        break
