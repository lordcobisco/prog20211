#INSTITUTO INTERNACIONAL DE NEUROCIÊNCIAS EDMOND E LILY SAFRA, IIN-ELS
#INSTITUTO SANTOS DUMONT
#PROGRAMA DE PÓS-GRADUAÇÃO EM NEUROENGENHARIA
#COMPONENENTE CURRICULAR: FUND. DE PROGRAMAÇÃO E DESENVOLVIMENTO DE PROJETOS APLICADOS A NEUROENGENHARIA
#DOCENTE: PROF. Dr. ANDRÉ FELIPE OLIVEIRA DE AZEVEDO DANTAS
#DISCENTE: YAGO DANIEL SOUTO


import math

print ("Cirurgia Esterotáxica Em Animais")


animais = int(input("Qual animal será operado? Digite 0 para a família dos roedores e 1 para a família de primatas não-humanos.\n"))
lista = ["Roedores","Primatas não-humanos"]

if animais == 0:
    print("O animal é da família dos: ", lista[0])

elif animais == 1:
    print("O animal é da família de: ", lista[1])



tipoanestesico = {"Ketamina", "90 a 120mg/kg","Xilazina","5 a 16mg/kg"}
anestesico = input("A dosagem do anestésico é de acordo com o peso do animal. Para mais informações digite 'Ketamina' ou 'Xilazina': \n")

if anestesico == "Ketamina":
    tipoanestesico = {"Ketamina":"90 a 120mg/kg"}
    print(tipoanestesico)
else:
    tipoanestesico = {"Xilazina":"5 a 16mg/kg"}
    print(tipoanestesico)

peso = float(input("Qual o peso do animal (em kg)?"))

ketamina = peso*100
xilazina = peso*12

print ("A dose de Ketamina a ser administrada para esse animal é de:", ketamina)
print ("A dose de Xilazina a ser administrada para esse animal é de:", xilazina)

#Procedimento II: Depois do anestésico ter feito efeito, deve-se posicionar o animal no estereotáxico. As barras 
# que suportam o peso do animal devem ser posicionadas no ouvido externo do animal. Normalmente o animal dá uma pequena 
# piscada, devido ao estímulo da musculatura responsável por este movimento. Em seguida verificar a angulação da cabeça 
# do animal, a qual deve estar sem diferenças de angulação entre o bregma e o lambda, para ter uma superfície de cirurgia 
# plana.

#Procedimento III: Limpeza do campo de trabalho: Este procedimento requer o cumprimento de algumas etapas: 
# Retirada da pelagem que recobre a parte superior da calota craniana, Retirada dos tecidos moles 
# (epiderme, derme e tecido conjuntivo) até alcançar a parte óssea da caixa craniana. Por último e não menos importante 
# deve-se limpar a calota craniana de qualquer resto de “pele” que esteja sobrando utilizando H2O2 10 volumes.

#Procedimento IV: Com o animal em posição e com o campo cirúrgico devidamente limpo, utiliza-se uma pequena camada de 
#poliacrilato em todo o perímetro externo para evitar sangramentos.



efeitoanestesico = input("O animal encontra-se anestesiado? Digite 0 para 'Sim' e 1 para 'Não'")

if efeitoanestesico == 0:
    print("O animal já pode ser posicionado no Estereotoráxico.")
    angulacaobregma = input("Qual o ângulo do Bregma?\n")
    angulacaolambda = input("Qual o ângudo da lambda?\n")

    while angulacaobregma != angulacaolambda:
        print("As angulações não estão iguais, logo, posicionar o animal corretamente.")
        angulacaobregma = input("Qual o valor do ângulo Bregma?\n")
        angulacaolambda = input("Qual o valor do ângulo lambda?\n")

print ("Esta etapa requer a limpeza do campo de trabalho cirurgico")
print ("Insira uma pequena camada de poliacrilato em todo o perímetro externo")


    # caixacraniana = int(input("A parte ossea da caixa craniana já foi alcançada? Digite 0 para 'Sim' e 1 para 'Não'"))

    # while caixacraniana != 0:
    #     print("O campo de trabalho ainda se encontra com tecido mole, portanto, retire-o!")
    #     caixacraniana = input("A caixa craniana já foi alcançada? Digite 0 para 'Sim' e 1 para 'Não'")

#Procedimento V: Após este procedimento deve-se escolher um ponto para a fixação de parafusos, de preferência 
#na parte posterior da calota craniana, pois a camada óssea é mais espessa e suporta uma maior profundidade do parafuso. 

    fixacaoparafusos = int(input("Escolha um ponto para a fixação dos parafusos."))
    quantidadedevoltas = 1

    for i in range(1,4):
        print("Já foram dadas", i, "voltas no parafuso.")
        print("Obs: Cuidado para não aprofundar muito o parafuso. Com parafusos maiores deve-se dar até 3 voltas no parafuso.")

    tamagulhaAP = 0
    tamagulhaLL = 0
    tamagulhaDV = 0

    AP = 6
    LL = 3.63
    DV = 4

#Procedimento VI: Após estes cálculos feitos é hora de localizar os pontos de inserção das cânulas-guia. Assim que 
# estes pontos forem localizados é necessário fazer furos para a introdução das cânulas-guia. A localização destes pontos 
# e ser definida pelos valores encontrados nos cálculos AnteroPosterior (6,00) e LateroLateral (3,63 e 3,03). 
# Deve-se escolher qual dos hemisférios vai ser colocada a primeira cânula, daí os dois valores para as medidas LL.

#Procedimento VII: Depois de posicionar a agulha, fazer um furo com a broca até alcançar as meninges. A não 
#perfuração das meninges é o procedimento ideal, e para conseguir isso apoie a mão que segura a broca contra o 
#assoalho ou ao estereotáxico e perfure o crânio a +- 450 de angulação.

#Procedimento VIII: Após ter atingido este objetivo, introduza a cânula-guia previamente confeccionada até o valor 
#DorsoVentral (4,00) que foi calculado anteriormente.

    canulaguia1 = 0

    while (canulaguia1 != DV):
        canulaguia1 += 1
        print("Introdução da cânula-guia1 previamente confeccionada até o valor Dorso Ventral.")

    if canulaguia1 == DV:
        print("A cânula-guia1 foi inserida.")

#Procedimento IX: Logo após drenar qualquer sangue ou líquido cefalorraquidiano 
#que esteja saindo pelo orifício criado no crânio. Para isso utilize pequenos rolos de papel absorvente.

#Procedimento X: Faça uma mistura do acrílico polimerizante com o solvente até ficar com textura espessa porém maleável 
#(o ideal é que a mistura seja capaz de cobrir a parte desejada sem escorrer por todo o crânio). Com essa mistura faça um 
#capacete abrangendo o crânio, a cânula-guia e o parafuso. Deixe secar até ficar suficientemente rígido. O tempo de 
#secagem varia de acordo com a temperatura e umidade da sala. 

#Procedimento XI: O próximo passo é a fixação da outra cânula-guia. Deve-se levantar levemente o braço do 
#estereotáxico cuidando para que a cânula-guia previamente fixada não se movimente. Logo após, posicionar a agulha 
#sobre o outro ponto de inserção da cânula-guia. Introduzir a cânula-guia até o valor DV (4,00) calculado previamente.

#Procedimento XII: Seguir novamente a descrição do item 9 e após fixar a cânula conforme item 10. 
#De preferência espalhar o cimento sobre a maior área do crânio, sempre deixando um espaço entre o capacete e 
#o início da área tecidual. Este cuidado previne de um futuro descolamento do capacete devido a entrada de 
#sangue ou outro líquido entre o capacete e o crânio.

    canulaguia2 = 0

    while (canulaguia2 != DV):
        canulaguia2 += 1
        print("Introdução da cânula-guia2 previamente confeccionada até o valor Dorso Ventral.")

    if canulaguia2 == DV:
        print("A cânula-guia2 foi inserida.")

#Procedimento XIII: XIII.	Levantar bem devagar seguindo as instruções do item contida no item 11. Acomodar o animal em 
#uma caixa aquecida por uma lâmpada e sem outros animais acordados. Assim que o animal despertar colocá-lo de volta a sua 
#caixa-moradia.


    print ("O procedimento da estereotaxia chegou ao fim!")



