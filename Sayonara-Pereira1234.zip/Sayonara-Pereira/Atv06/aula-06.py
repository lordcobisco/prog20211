'''ITERAÇÃO

> ação de repetir algo:
    - estrutura de repetição
    - laço de repetição
    - laços condicionais
    - repetição'''

    #label REPETIÇÃO:
    #linha1
    #linha2
    #linha3

    #SE (true):
        #goto REPETIÇÃO
    #SENÃO
        #instrução


# lista = [1,2,3,4,5,6,7,8,9,10]

# for conteudoLista in lista: #pegue, um a um, o conteúdo da lista e coloque na varíavel conteudoLista
#    print(conteudoLista)


# range gera uma lista sequencial, utilizada caso houvesse várias listas de origens diferentes e se quisesse sincronizar os dados

# lista1 = [9,8,7,6,5,4,3,2,1]
# lista2 = ['um', 'dois', 3,4,5]

# for i in range(5):
#     print(i, lista1[i],lista2[i])
# print('Fim de programa')

#for i in range(5,0,-1):
#    print(i, lista1[i])


# listaQualquerCoisa = [1, 2.5, 24, 'letras', ['mais letras', 4], {'chave': 'conteudo'}]
# for conteudoLista in listaQualquerCoisa:
#     print(conteudoLista)

# for i in range(6):
#     print(listaQualquerCoisa[i])

# dadosDeIMU = {'head':[1,2,3,4,5],'spine_01':[1,2,3,4], 'calf_r':[1,2,3,4,5,6,7,8,9]}
# for chave in dadosDeIMU:
#     print(chave)
#     print(chave, dadosDeIMU[chave])
#     print('Fim de programa')

# covid = {'Brasil':
#             {'Nordeste':
#                 {'RN':
#                     {'Macaíba': 
#                         {'obtosAcumulados':[1,2,3,4,5]}
#                     }
#                 },
#             'Norte': 
#                 {'AM': 
#                     {'Manaus': 
#                         {'obtosAcumulados': [123,123,123]}
#                     }
#                 }
#             }
# }         
# for regioes in covid['Brasil']:
#     print(regioes)
#     for estados in covid['Brasil'][regioes]:
#         print(estados)

# comidas = ['bacon', 'fritas', 'picanha']
# bebidas = ['cerveja', 'refrigerante', 'suco']
# for comida,bebida in zip(comidas,bebidas):
#     print(comida,bebida)

'''REPETIÇÃO CONDICIONAL'''

# WHILE FAZ COM QUE UM CONJUNTO DE INSTRUções seja executado enquanto uma condição for atendida (true)
# quando o resultado passa a ser falto a execução é interrompida e passa para o próximo bloco 

# condicao = bool(int(input('Digite 0 ou 1\n')))
# while condicao:
#     print('Entrou porque a condição é verdadeira')

# contador = 0
# while contador <= 5:
#     print(contador)
#     contador +=1
#     if contador  == 3:
#         break

# dadosCovid = [[1,2,3,4,5,6],[7,8,9,10,0,1]]
# contador = 0
# while contador < 2:
#     print(dadosCovid[contador])
#     if dadosCovid[contador] == 10:
#         contador +=1
#         continue
#     if sum(dadosCovid[contador]) >= 25:
#         continue
    
