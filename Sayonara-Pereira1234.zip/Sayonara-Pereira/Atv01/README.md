# code_treino_locomotor

Desenvolvimento de rotinas para equipamentos robóticos que objetivam treino locomotor.
O equipamento pode ser utilizado para tratamento de condições enfrentadas por pessoas com deficiência física, como lesão modular.

Atividade desenvolvida para disciplina Fundamentos de Programação - IINELS/ISD 2021.2
