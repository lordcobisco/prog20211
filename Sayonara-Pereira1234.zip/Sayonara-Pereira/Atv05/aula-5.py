'''AULA 5: TIPOS DE DADOS COMPOSTOS'''
# string, tupla, lista, dicionário, set

# LISTAS:
# sequência de objetos separados por vírgula e dentro de colchetes []

#lista = [] ------ lista = list()
#print(lista)

#lista = ['Sayonara',24,3.2] ---- lista = list(['Sayonara',24,3.2])
#print(lista)

#lista dentro da lista: lista = list(['Sayonara',24,3.2,[outra,lista,mais,itens]])

#diasDaSemana = ['segunda','terça','quarta','quinta','sexta',['sábado','domingo']]
#print(diasDaSemana[0])
#print(diasDaSemana[1])
#print(diasDaSemana[2])
#print(diasDaSemana[3])
#print(diasDaSemana[4])
#print(diasDaSemana[5])
#print(diasDaSemana[1][1])

'''INPUT PARA LISTA E APRESENTAÇÃO'''

#listaCursos = ['','']
#listaCursos[0] = input('Digite o curso desejado\n')
#listaCursos[1] = input('Digite o curso desejado\n')
#print(listaCursos)

#listaCursosDisponiveis = ['bigData', 'fundamentos de programação', listaCursos]
#print(listaCursosDisponiveis)

# listaCursosDisponiveis = []
# listaCursosDisponiveis = [listaCursosDisponiveis, input('Digite o curso desejado\n')]
# print(listaCursosDisponiveis)

#diasDaSemana = list(['segunda','terça','quarta','quinta','sexta',['sábado','domingo']])
#print(diasDaSemana[-2])
'''PARA SABER O TAMANHO DA LISTA'''
#print(len(diasDaSemana))

'''OPERAÇÕES'''
# print(diasDaSemana+[1,2,3])
# print(diasDaSemana*2)
# print(diasDaSemana + ['mes'])
# print('segunda' in diasDaSemana)
# print('Janeiro' in diasDaSemana)

# listaNumeros = [1, 3, 9, 8, 15]
# print(max(listaNumeros))
# print(min(listaNumeros))
# print(sum(listaNumeros))
# print(sum(listaNumeros)/len(listaNumeros))
# listaNumeros.remove(15)
# print(listaNumeros)
# listaNumeros.reverse()
# print(listaNumeros)
# listaNumeros.sort()
# print(listaNumeros)

# listaMarcaCarros = []
# listaMarcaCarros.insert(0, input('Digite a marca do carro\n'))
# print(listaMarcaCarros)
# listaMarcaCarros.insert(1, input('Digite a marca do carro\n'))
# print(listaMarcaCarros)
# listaMarcaCarros.append(input('Digite a marca desejada\n'))

'''ALIASING AND CLONING'''

# a = [71, 27, 49]
# b = a
# print(a is b)
# b.insert(3, 25)
# print(a)

# a = [71, 27, 49]
# b = a[:]
# print (a == b)

#memória, operações, acesso

'''TUPLAS'''
#lista imutável que restringe alterações e remoção de elementos; possui as mesmas características fundamentais da lista
#lista é uma estrutura de dados homogêneos e tuplas é uma estrutura de dados heterogêneos
#tipos distintos

'''COMO CRIAR UMA TUPLA'''
# tupla = (1,2,3,4)
# print(tupla)
# tupla = (1,)
# print(tupla)
# tupla = ()
# print(tupla)
# tupla = tuple()
# print(tupla)

# tuplaDeStrings = ('palavras', 'outras palavras', 'mais algumas palavras')
# print(tuplaDeStrings[0:3])
# print(tuplaDeStrings[:2])

'''DICIONÁRIOS'''

# dicionario = {}
# dicionario = dict()
# dicionario['biblioteca'] = 'Estantes'
# print(dicionario)
# print(dicionario['biblioteca'])

dicionario = {}
dicionario['biblioteca'] = {'estantes':[1,2,3,4,5,6,7,8], 'livros':[]}
print(dicionario)
print(dicionario['biblioteca'])
print(dicionario['biblioteca']['estantes'])
print(dicionario['biblioteca']['estantes'][0])
print(dicionario.keys())
print(dicionario['biblioteca'].keys())
