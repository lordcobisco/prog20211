#codigos de saúde não disponíveis no arquivo, substitui por regiões do brasil

norte = ['AC', 'AM', 'PA', 'RR', 'RO', 'TO', 'AP']
nordeste = ['BA', 'CE', 'RN', 'PB', 'PI', 'MA', 'AL', 'SE', 'PE']
sul = ['RS', 'SC', 'PR']
sudeste = ['SP', 'RJ', 'ES', 'MG']
centroOeste = ['GO', 'MT', 'MS', 'DF']

norteTupla = ('AC', 'AM', 'PA', 'RR', 'RO', 'TO', 'AP')
nordesteTupla = ('BA', 'CE', 'RN', 'PB', 'PI', 'MA', 'AL', 'SE', 'PE')
sulTupla = ('RS', 'SC', 'PR')
sudesteTupla = ('SP', 'RJ', 'ES', 'MG')
centroOesteTupla = ('GO', 'MT', 'MS', 'DF')

casosAcumuladosTuplaRJ = (sudesteTupla[1], 1116338)

casosAcumuladosNorte = [norte[4], 262411, norte[0], 8779, norte[1], 423524, norte[2], 581788, norte[3], 123121, norte[6], 122333, norte[5], 217396]
casosAcumuladosNordeste = [nordeste[0], 1216546, nordeste[1], 929670, nordeste[2], 364406, nordeste[3], 431090, nordeste[4], 315337, nordeste[5], 347057, nordeste[6], 234729, nordeste[7], 277283, nordeste[8], 604991]
casosAcumuladosSul = [sul[0], 1403339, sul[1], 1148649, sul[2], 1447855]
casosAcumuladosSudeste = [sudeste[0], 4229600, sudeste[1], 1116338, sudeste[2], 558720, sudeste[3], 2051177]
casosAcumuladosCentroOeste = [centroOeste[0], 805103, centroOeste[1], 512036, centroOeste[2], 367015, centroOeste[3], 466294]
print(('Este é o número de casos acumulados no Estado solicitado \n'), sudeste[1], casosAcumuladosSudeste[3])
print(('Este é o número de casos guardado em uma Tupla \n'), casosAcumuladosTuplaRJ)