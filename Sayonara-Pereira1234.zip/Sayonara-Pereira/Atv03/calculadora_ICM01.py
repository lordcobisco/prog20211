
Peso = 36.7
Altura = 1.78

ICM = Peso/(Altura**2)
print(ICM)
print(ICM < 17, "Cuidado! ICM muito abaixo da média, procure um especialista!")


Peso = 55.9
Altura = 1.80

ICM = Peso/(Altura**2)
print(ICM)
print(17 < ICM < 18.5, "Cuidado! ICM abaixo da média.")


Peso = 62
Altura = 1.69

ICM = Peso/(Altura**2)
print(ICM)
print(18.5 < ICM < 25, "Parabéns! ICM normal!")


Peso = 74
Altura = 1.50

ICM = Peso/(Altura**2)
print(ICM)
print(25 < ICM < 30, "Alerta! ICM acima da média.")


Peso = 87
Altura = 1.53

ICM = Peso/(Altura**2)
print(ICM)
print(ICM > 30, "Alerta! ICM muito acima da média, procure um especialista.")
